package com.cts.mfrp.bo;


import com.cts.mfrp.dao.Userdao;
import com.cts.mfrp.vo.Uservo;


public class Userbo {
                Userdao udao=null;

                public Userbo()
                {
                                udao=new Userdao();
                }

                public void validateDetails(Uservo uvo) {
                                
                                 udao.validateDetails(uvo);
                                
                }
                public void insertDetails(Uservo uvo) {
                    
                    udao.insertDetails(uvo);
                   
   }

}


