package com.cts.mfrp.bo;

import java.util.List;


import com.cts.mfrp.dao.Bookdao;
import com.cts.mfrp.vo.Bookvo;

public class Bookbo 
{
    Bookdao bdao=null;
    public Bookbo()
    {
                bdao=new Bookdao();
    }

public  List<Bookvo> getAllDetails()
   {
                   return bdao.getAllDetails();
   }

}
