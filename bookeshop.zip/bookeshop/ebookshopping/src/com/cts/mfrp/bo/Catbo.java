package com.cts.mfrp.bo;

import java.util.List;

import com.cts.mfrp.dao.Catdao;
import com.cts.mfrp.vo.Ordertransvo;
import com.cts.mfrp.vo.Uservo;

public class Catbo {
	Catdao cdao;
	public Catbo(){
		cdao=new Catdao();
	}
	public List<Ordertransvo> getOrderDetails(Uservo uvo){
		return cdao.getOrderDetails(uvo);
	}
	public void insertDet(List<Ordertransvo> lst)
	{
		cdao.insertDet(lst);
	}
	public void deleteDetails(Uservo uvo){
		cdao.deleteDetails(uvo);
	}
}
