package com.cts.mfrp.bo;

public class Order_transactionbo {

}
