package com.cts.mfrp.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.mfrp.bo.Catbo;
import com.cts.mfrp.vo.Bookvo;
import com.cts.mfrp.vo.Ordermaster;
import com.cts.mfrp.vo.Ordertransvo;
import com.cts.mfrp.vo.Uservo;

/**
 * Servlet implementation class Cartserv
 */
public class Cartserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cartserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("id")!=null){
			System.out.println("In Delete");
			HttpSession session=request.getSession();
			List<Ordertransvo> lst=(List<Ordertransvo>)session.getAttribute("ordlst");
			String bname=request.getParameter("id").trim();
			for(int i=0;i<lst.size();i++){
				String bname1=lst.get(i).getBvo().getBookname();
				if(bname.equals(bname1.trim())){
					lst.remove(i);
				}
			}
			response.sendRedirect("Cart.jsp");
		}
		
			else{
		
		HttpSession session=request.getSession();
		List<Ordertransvo> lst=(List<Ordertransvo>)session.getAttribute("ordlst");
		
		
		
		
		 
		
		
		
		
		
		
		
		
		String Details=request.getParameter("changeFlg");
		String ordDet[]=Details.split(",");
		System.out.println("LLLL"+ordDet[0]);
		
		for(String ord:ordDet){
		if(ord.equals("")){
			continue;
		}
			String det[]=ord.split("-");
			String bname=det[0];
			
			String Qty=det[1];
			
	
			String subtot=det[2];
			
			
			for(Ordertransvo ordvo:lst){
				//System.out.println("Bookname="+ordvo.getBvo().getBookname().equals(bname));
				//System.out.println(bname);
				//System.out.println(ordvo.getBvo().getBookname());
				//System.out.println("***********************");
				if(ordvo.getBvo().getBookname().trim().equals(bname.trim())){
					//System.out.println("Befor::"+ordvo.getQty());
					ordvo.setQty(Integer.parseInt(Qty));
				//	System.out.println("Befor::"+ordvo.getQty());
					ordvo.setSubtot(Integer.parseInt(subtot));
				}
			}
			
			
			session.setAttribute("OrderList",lst);
			
		}
		
		Catbo cbo=new Catbo();
		cbo.insertDet(lst);
		response.sendRedirect("Payment.jsp?ordid="+lst.get(0).getOrdm().getId());
		}
		
			
		}

			
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String Book_detail=request.getParameter("bdet");
		String Books[]=Book_detail.split(",");
		
		HttpSession session=request.getSession();
		List<Ordertransvo> lst=(List<Ordertransvo>)session.getAttribute("ordlst");
		System.out.println(lst.size());
		if(lst.size()<1){
			lst=new ArrayList<Ordertransvo>();
		}
		Uservo uvo=(Uservo)session.getAttribute("uvo");
		Ordermaster orm=new Ordermaster();
		orm.setUvo(uvo);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date d=new Date();
		orm.setDate(sdf.format(d));
	for(String Book:Books){
		
		Ordertransvo ordvo=new Ordertransvo();
		
		System.out.println(Book);
		
		String B[]=Book.split("-");
			Bookvo bvo=new Bookvo();
			bvo.setBookid(Integer.parseInt(B[0]));
			bvo.setBookname(B[1]);
	     	bvo.setPrice(B[2]);
		ordvo.setOrdm(orm);
		ordvo.setQty(1);
		ordvo.setSubtot(Integer.parseInt(B[2]));
			ordvo.setBvo(bvo);
			//System.out.println(orm.getTotal()+Integer.parseInt(B[1]));
			orm.setTotal(orm.getTotal()+Integer.parseInt(B[2]));
			System.out.println(ordvo.getOrdm().getTotal());
		lst.add(ordvo);
		}
	for(Ordertransvo ordvo:lst){
		System.out.println(ordvo);
	}
	session.setAttribute("ordlst", lst);
		
		/*
		List<Bookvo> lst=new ArrayList<Bookvo>();
		for(String Book:Books){
			String B[]=Book.split("-");
			Bookvo bvo=new Bookvo();
			bvo.setBookname(B[0]);
			bvo.setPrice(B[1]);
			lst.add(bvo);
		
		}
		HttpSession session=request.getSession();
		if(session.getAttribute("cartlst")==null){
		session.setAttribute("cartlst", lst);
		}
		else
		{
			List<Bookvo> lst1= (List<Bookvo>)session.getAttribute("cartlst");
			lst1.addAll(lst);
			session.setAttribute("cartlst", lst);
		}*/
		response.sendRedirect("Cart.jsp");
	
		
		
		
		
	}

}
