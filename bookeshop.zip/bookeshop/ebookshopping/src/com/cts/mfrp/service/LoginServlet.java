package com.cts.mfrp.service;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.mfrp.bo.Bookbo;
import com.cts.mfrp.bo.Catbo;
import com.cts.mfrp.bo.Userbo;
import com.cts.mfrp.vo.Bookvo;
import com.cts.mfrp.vo.Ordertransvo;
import com.cts.mfrp.vo.Uservo;



public class LoginServlet extends HttpServlet {
                private static final long serialVersionUID = 1L;

                
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                //int stno=Integer.parseInt(request.getParameter("uid"));
                                
                }

                
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                	response.setContentType("text/html");
                    PrintWriter out=response.getWriter();
                    
                   
                    
                    
                    
                    
                	if(request.getParameter("flag").equals("login"))
                	{
                                
        
                                String emailid=request.getParameter("emailid");
                                String password=request.getParameter("password");
                                Uservo uvo=new Uservo();
                                uvo.setEmailid(emailid);
                                uvo.setPassword(password);
                                Userbo ubo=new Userbo();
                                ubo.validateDetails(uvo);
                                HttpSession session=request.getSession();
                                session.setAttribute("uvo", uvo);
                                if(uvo.getLastname()!=null)
                                {
                                	//System.out.println("Record present");
                                	//RequestDispatcher rd=request.getRequestDispatcher("PdtList.jsp");  
                                	//rd.forward(request, response);  
                                	
                                	 Bookbo bbo = new Bookbo();
                                     List<Bookvo> list = bbo.getAllDetails();
                                //	 System.out.println(list.size());
                                     session.setAttribute("BookList",list);
                                     
                                     Catbo cbo=new Catbo();
                                     List<Ordertransvo> ordlst=cbo.getOrderDetails(uvo);
                                     session.setAttribute("ordlst", ordlst);
                                     
                                     response.sendRedirect("PdtList.jsp");
                                	//response.sendRedirect("PdtList.jsp");

                                }
                                else 
                                {
                                	response.sendRedirect("Login.jsp");
                                out.println("invalid user");
                                	
                                       //RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");  
                                       //rd.forward(request, response);  
                              //  HttpSession session=request.getSession();
                               // session.setAttribute("lvo",lvo);
                               // request.setAttribute("msg", "Sorry invalid.");
                               // RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                               // rd.forward(request, response);
 

                                }
        
                	}
                                
                
                else if(request.getParameter("flag").equals("registration"))
                {
                	String firstname=request.getParameter("firstname");
                    String lastname=request.getParameter("lastname");
                    int age=Integer.parseInt(request.getParameter("age"));
                    String gender=request.getParameter("gender");
                    String phonenumber=request.getParameter("phonenumber");
                    String emailid=request.getParameter("emailid");
                    String password=request.getParameter("password");
                    Userbo ubo=new Userbo();
                    Uservo uvo=new Uservo(firstname,lastname,age,gender,phonenumber,emailid,password);
                    ubo.insertDetails(uvo);
                    HttpSession session=request.getSession();
                    session.setAttribute("uvo", uvo);
                    Catbo cbo=new Catbo();
                    List<Ordertransvo> ordlst=cbo.getOrderDetails(uvo);
                    session.setAttribute("ordlst", ordlst);
                    
                  /*  Bookbo bbo = new Bookbo();
                    //List<Bookvo> list = bdao.getAllDetails();
                    session.setAttribute("list",bbo.getAllDetails());
                    response.sendRedirect("PdtList.jsp");*/
                    response.sendRedirect("Login.jsp");
                    		
                }
                
                
        }

                

}



