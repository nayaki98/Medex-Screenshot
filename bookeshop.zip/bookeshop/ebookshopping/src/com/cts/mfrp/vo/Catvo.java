package com.cts.mfrp.vo;

public class Catvo {

}
