package com.cts.mfrp.vo;

public class Bookvo {
	

        private int bookid;
        public void setBookid(int bookid) {
			this.bookid = bookid;
		}
        public int getBookid() {
			return bookid;
		}
        
		private String bookname;
        private String price;
        private String language;
        private String authorname;
        private String publishername;
        private int quantity;
        
        public Bookvo() {
			super();
		}
		public Bookvo(String bookname, String price, String language,
				String authorname, String publishername, int quantity) {
			super();
			this.bookname = bookname;
			this.price = price;
			this.language = language;
			this.authorname = authorname;
			this.publishername = publishername;
			this.quantity = quantity;
		}
		public String getBookname() {
			return bookname;
		}
		public void setBookname(String bookname) {
			this.bookname = bookname;
		}
		public String getPrice() {
			return price;
		}
		public void setPrice(String price) {
			this.price = price;
		}
		public String getLanguage() {
			return language;
		}
		public void setLanguage(String language) {
			this.language = language;
		}
		public String getAuthorname() {
			return authorname;
		}
		public void setAuthorname(String authorname) {
			this.authorname = authorname;
		}
		public String getPublishername() {
			return publishername;
		}
		public void setPublishername(String publishername) {
			this.publishername = publishername;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		
	                
	     public String toString() {
	                                return " " + bookname + ", price=" + price + ", language="
	                                                                + language + ", authorname=" + authorname + ",publishername=" + publishername + ", quantity=" + quantity + "";
	                }
} 
	                

	                

	



