package com.cts.mfrp.vo;

import java.util.Date;

public class Ordermaster {
	
	private int id;
	private String  date;
	private Uservo uvo;
	private int total;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Uservo getUvo() {
		return uvo;
	}
	public void setUvo(Uservo uvo) {
		this.uvo = uvo;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public Ordermaster(int id, String date, Uservo uvo, int total) {
		super();
		this.id = id;
		this.date = date;
		this.uvo = uvo;
		this.total = total;
	}
	public Ordermaster() {
		super();
	}
	@Override
	public String toString() {
		return "Ordermaster [id=" + id + ", date=" + date + ", uvo=" + uvo
				+ ", total=" + total + "]";
	}


}
