package com.cts.mfrp.vo;

public class Ordertransvo {

	
	@Override
	public String toString() {
		return "Ordertransvo [id=" + id + ", ordm=" + ordm + ", bvo=" + bvo
				+ ", Qty=" + Qty + ", subtot=" + subtot + "]";
	}
	private int id;
	private Ordermaster ordm;
	private Bookvo bvo;
	private int Qty,subtot;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Ordermaster getOrdm() {
		return ordm;
	}
	public void setOrdm(Ordermaster ordm) {
		this.ordm = ordm;
	}
	public Bookvo getBvo() {
		return bvo;
	}
	public void setBvo(Bookvo bvo) {
		this.bvo = bvo;
	}
	public int getQty() {
		return Qty;
	}
	public void setQty(int qty) {
		Qty = qty;
	}
	public int getSubtot() {
		return subtot;
	}
	public void setSubtot(int subtot) {
		this.subtot = subtot;
	}
	public Ordertransvo(int id, Ordermaster ordm, Bookvo bvo, int qty,
			int subtot) {
		super();
		this.id = id;
		this.ordm = ordm;
		this.bvo = bvo;
		Qty = qty;
		this.subtot = subtot;
	}
	public Ordertransvo() {
		super();
	}
	
	
	
}
