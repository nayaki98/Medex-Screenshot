package com.cts.mfrp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.mfrp.vo.Bookvo;
import com.cts.mfrp.vo.Ordermaster;
import com.cts.mfrp.vo.Ordertransvo;
import com.cts.mfrp.vo.Uservo;

public class Catdao {

	Connection con;
	PreparedStatement pt;
	public Catdao(){
		
		con=Dbconnector.getConnection();
		
	}
	public void deleteOrder(int oid){
		
		try {
			pt=con.prepareStatement("delet from order_master where oid="+oid);
			pt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public List<Ordertransvo> getOrderDetails(Uservo uvo){
		List<Ordertransvo> lst=new ArrayList<Ordertransvo>();	
		
		
		String str="select om.oid,om.odate,om.total,ot.bookid,"
				+ "b.bookname,"
        		+ "ot.quantity,ot.subtotal,b.price from"
        		+ " order_master om join order_transaction ot "
        		+ "on om.oid=ot.oid "
        		+ "join tbbook b on b.bookid=ot.bookid where om.uid="+uvo.getId();
		
		try {
			pt=con.prepareStatement(str);
			ResultSet rs=pt.executeQuery();
			
			while(rs.next()){
				Ordermaster ordm=new Ordermaster();
				ordm.setId(rs.getInt(1));
				System.out.println(ordm.getId()+":::::");
				ordm.setDate(rs.getString(2));
				ordm.setTotal(rs.getInt(3));
				
				
				ordm.setUvo(uvo);
				Ordertransvo otvo=new Ordertransvo();
				
				Bookvo bvo=new Bookvo();
				bvo.setBookid(rs.getInt(4));
				bvo.setBookname(rs.getString(5));
				
				otvo.setBvo(bvo);
				otvo.setQty(rs.getInt(6));
				otvo.setSubtot(rs.getInt(7));
				bvo.setPrice((rs.getString(8)));
				otvo.setOrdm(ordm);
				lst.add(otvo);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
        
		return lst;
		
	}
	public void insertDet(List<Ordertransvo> lst){
		int flg=0;
		int oid=0;
		for(Ordertransvo ordvo:lst){
			
			try {
			if(flg==0){
			String odate=ordvo.getOrdm().getDate();
			int uid=ordvo.getOrdm().getUvo().getId();
			int total=ordvo.getOrdm().getTotal();
			String str="insert into order_master(odate,uid,total) values(?,?,?)";
			
				pt=con.prepareStatement(str);
				pt.setString(1, odate);
				pt.setInt(2, uid);
				pt.setInt(3, total);
				pt.execute();
				 oid=maxId1();
				
				flg++;
			}
				
				int tid=maxId();
				tid++;
				int bookid=ordvo.getBvo().getBookid();
				int quantity=ordvo.getQty();
				int subtotal=ordvo.getSubtot();
				String str="insert into order_transaction values(?,?,?,?,?)";
				pt=con.prepareStatement(str);
				pt.setInt(1, tid);
				pt.setInt(2, oid);
				pt.setInt(3, bookid);
				pt.setInt(4, quantity);
				pt.setInt(5, subtotal);
				pt.execute();
				
								
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

		}
	}
	
	public int maxId1(){
		int id=0;
		String str="select max(oid) from order_master";
		try{
		pt=con.prepareStatement(str);
		ResultSet rs=pt.executeQuery();
		while(rs.next()){
			id=rs.getInt(1);
		}
		}
		catch(Exception e){
			
		}
		return id;
	}
	
	public int maxId(){
		int id=0;
		String str="select max(tid) from order_transaction";
		try{
		pt=con.prepareStatement(str);
		ResultSet rs=pt.executeQuery();
		while(rs.next()){
			id=rs.getInt(1);
		}
		}
		catch(Exception e){
			
		}
		return id;
	}
	public void deleteDetails(Uservo uvo){
		try {
			pt=con.prepareStatement("delete from order_master where uid="+uvo.getId());
			pt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
//		Catdao catdao=new Catdao();
//		Uservo uvo=new Uservo();
//		catdao.getOrderDetails()
	}
	
}
