package com.cts.mfrp.dao;


import java.sql.SQLException;

import com.cts.mfrp.vo.Bookvo;
//import com.cts.mfrp.vo.Uservo;






import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Bookdao {

                Connection con=null;
                PreparedStatement st;
                public Bookdao()
                {
                                con=Dbconnector.getConnection();  
                }
                public List<Bookvo> getAllDetails()
                {
                                List<Bookvo> list=new ArrayList<Bookvo>();
                                try{
                                                st=con.prepareStatement("select bookname,price,language,authorname,publishername,quantity,bookid from tbbook");
                                                ResultSet rs=st.executeQuery();
                                                while(rs.next())
                                                {
                                                                Bookvo bvo=new Bookvo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6));
                                                                bvo.setBookid(rs.getInt(7));
                                                                list.add(bvo);
                                                }
                                                }
                                
                                catch(SQLException e)
                                  {
                                                  e.printStackTrace();
                                  }
                                return list;
                                }
                
public static void main(String[] args)
{
	Bookdao bdao=new Bookdao();
	List<Bookvo> list = bdao.getAllDetails();
	for(Bookvo bvo:list)
	{
		System.out.println(bvo);
	}
 }
                
}
