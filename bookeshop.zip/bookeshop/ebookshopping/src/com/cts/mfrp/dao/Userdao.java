package com.cts.mfrp.dao;


import java.sql.SQLException;


import com.cts.mfrp.vo.Uservo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



public class Userdao {

                Connection con=null;
                PreparedStatement st;
                public Userdao()
                {
                                con=Dbconnector.getConnection();  
                }
                public void insertDetails(Uservo uvo)
                {
                                String sqr="insert into tbuser (firstname,lastname,age,gender,phonenumber,emailid,password) values(?,?,?,?,?,?,?)";
                                try
                                {
                                st=con.prepareStatement(sqr);
                                st.setString(1,uvo.getFirstname());
                                st.setString(2,uvo.getLastname());
                                st.setInt(3,uvo.getAge());
                                st.setString(4,uvo.getGender());
                                st.setString(5,uvo.getPhonenumber());
                                st.setString(6,uvo.getEmailid());
                                st.setString(7,uvo.getPassword());
                                st.execute();
                                }
                                catch(SQLException e)
                                {
                                                e.printStackTrace();
                                }
                }
                public void validateDetails(Uservo uvo)
                {
                
                String str="select * from tbuser where emailid=? and password=?";
                
                
                  try
                  {

                st= con.prepareStatement(str);
                st.setString(1,uvo.getEmailid());
                st.setString(2,uvo.getPassword());
                
                ResultSet rs=st.executeQuery();
                while(rs.next())
                {
                	System.out.println();
                	uvo.setId(rs.getInt(1));
                               uvo.setFirstname(rs.getString(2));
                               uvo.setLastname(rs.getString(3));
                               uvo.setAge(rs.getInt(4));
                               uvo.setGender(rs.getString(5));
                               uvo.setPhonenumber(rs.getString(6));
                               uvo.setEmailid(rs.getString(7));
                               uvo.setPassword(rs.getString(8));
                               
                				}
                
                  }
                  catch(SQLException e)
                  {
                	  e.printStackTrace();
                  }
                }
                
                public static void main(String args[])
                {
                               Userdao udao=new Userdao();
                               Uservo uvo=new Uservo();
                                	uvo.setEmailid("muthupriyacse@gmail.com");
                                	uvo.setPassword("12345");
                                udao.validateDetails(uvo);
                                System.out.println(uvo.getFirstname());
                                
                }
                
}
                

