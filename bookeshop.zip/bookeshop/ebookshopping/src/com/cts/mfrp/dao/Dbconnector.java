package com.cts.mfrp.dao;

import java.sql.DriverManager;

import java.sql.Connection;



public class Dbconnector {
private static Connection con=null;
static Connection getConnection()
{
                try
                {
                                Class.forName("com.mysql.jdbc.Driver");
                                con=DriverManager.getConnection("jdbc:Mysql://localhost:3306/dbbook","root","root");
                                
                }
                catch(Exception e)
                {
                                e.printStackTrace();
                }
                return con;
}
                
}
